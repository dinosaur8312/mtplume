# -*- coding: utf-8 -*-
"""
Created on Wed Jan 24 17:59:25 2024

@author: Stage
"""

import math

HPAC_COEF_FILE = 'hpac_dispersion_coefs.csv'

TWO_PI = math.pi * 2

ROOT_TWO_PI = math.sqrt(TWO_PI)